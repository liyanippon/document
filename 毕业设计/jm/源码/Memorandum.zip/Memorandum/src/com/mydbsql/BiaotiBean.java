package com.mydbsql;

public class BiaotiBean {

	private String biaoti;

	public BiaotiBean() {
	}

	public BiaotiBean(String biaoti) {
		this.biaoti = biaoti;
	}

	public String getBiaoti() {
		return biaoti;
	}

	public void setBiaoti(String biaoti) {
		this.biaoti = biaoti;
	}

}
