package com.mydbsql.view;

public class FenYeBean {

	private int shang;
	private int xia;

	public FenYeBean() {
	}

	public FenYeBean(int shang, int xia) {
		this.shang = shang;
		this.xia = xia;
	}

	public int getShang() {
		return shang;
	}

	public void setShang(int shang) {
		this.shang = shang;
	}

	public int getXia() {
		return xia;
	}

	public void setXia(int xia) {
		this.xia = xia;
	}

}
